import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import {
  DocumentTextIcon,
  CalendarDaysIcon,
  BanknotesIcon,
  ArrowRightIcon,
  CheckCircleIcon,
  ArrowTopRightOnSquareIcon,
  ShieldCheckIcon,
  SparklesIcon,
  CheckBadgeIcon,
} from '@heroicons/react/24/outline';
import SEO from '../components/seo/SEO';
import Logo from '../assets/irsLogo.png';

// 3D Fintech Section Visuals
import formsVisual from '../assets/tax-resources-forms-3d.jpg';
import deadlinesVisual from '../assets/tax-resources-deadlines-3d.jpg';
import deductionsVisual from '../assets/tax-resources-deductions-3d.jpg';

const TaxResources = () => {
  // 1. Essential IRS Forms
  const essentialForms = [
    {
      code: 'Form 1040',
      name: 'Individual Income Tax Return',
      tag: 'Individual',
      summary: 'The core annual form for reporting gross income, claiming deductions, and securing your federal refund.',
      formUrl: 'https://www.irs.gov/pub/irs-pdf/f1040.pdf',
      instructionsUrl: 'https://www.irs.gov/pub/irs-pdf/i1040gi.pdf',
    },
    {
      code: 'Form 1040-NR',
      name: 'Nonresident Alien Return',
      tag: 'Expats & Visa',
      summary: 'Required for nonresidents, international students, and foreign professionals with U.S.-sourced income.',
      formUrl: 'https://www.irs.gov/pub/irs-pdf/f1040nr.pdf',
      instructionsUrl: 'https://www.irs.gov/pub/irs-pdf/i1040nr.pdf',
    },
    {
      code: 'Form W-7',
      name: 'Application for ITIN',
      tag: 'Identification',
      summary: 'Used by nonresidents, spouses, and dependents to apply for an IRS Individual Taxpayer ID.',
      formUrl: 'https://www.irs.gov/pub/irs-pdf/fw7.pdf',
      instructionsUrl: 'https://www.irs.gov/pub/irs-pdf/iw7.pdf',
    },
    {
      code: 'FinCEN 114',
      name: 'FBAR Foreign Accounts Report',
      tag: 'Foreign Assets',
      summary: 'Mandatory annual filing for U.S. persons holding foreign financial accounts exceeding $10,000.',
      formUrl: 'https://www.fincen.gov/sites/default/files/shared/fin114.pdf',
      instructionsUrl: 'https://www.fincen.gov/sites/default/files/shared/fin114_a.pdf',
    },
    {
      code: 'Form 4868',
      name: 'Automatic 6-Month Extension',
      tag: 'Extension',
      summary: 'Grants an extension to file returns through October 15 (taxes owed still due April 15).',
      formUrl: 'https://www.irs.gov/pub/irs-pdf/f4868.pdf',
      instructionsUrl: 'https://www.irs.gov/pub/irs-pdf/i4868.pdf',
    },
    {
      code: 'Schedule C',
      name: 'Business Profit & Loss',
      tag: 'Self-Employed',
      summary: 'Used by sole proprietors, freelancers, and 1099 contractors to report income and write off expenses.',
      formUrl: 'https://www.irs.gov/pub/irs-pdf/f1040sc.pdf',
      instructionsUrl: 'https://www.irs.gov/pub/irs-pdf/i1040sc.pdf',
    },
  ];

  // 2. Key Deadlines (Clean Schedule Data)
  const keyDeadlines = [
    {
      month: 'JAN',
      day: '31',
      date: 'January 31, 2026',
      title: 'W-2 & 1099 Forms Distribution',
      note: 'Employers and payers must mail or electronically deliver all wage and income statements.',
      tag: 'Forms Due',
      highlight: false,
    },
    {
      month: 'APR',
      day: '15',
      date: 'April 15, 2026',
      title: 'Individual Tax Filing & Payment Deadline',
      note: 'Primary federal & state income tax deadline (Form 1040) and payment for taxes owed.',
      tag: 'Primary Tax Day',
      highlight: true,
    },
    {
      month: 'JUN',
      day: '15',
      date: 'June 15, 2026',
      title: 'U.S. Expats & Overseas Filers Deadline',
      note: 'Automatic 2-month extension for citizens and permanent residents living abroad.',
      tag: 'Overseas Filers',
      highlight: false,
    },
    {
      month: 'OCT',
      day: '15',
      date: 'October 15, 2026',
      title: 'Extended Filing Final Deadline',
      note: 'Final deadline to file individual returns if you requested a Form 4868 extension.',
      tag: 'Extension Final',
      highlight: false,
    },
  ];

  // 3. Deduction Highlights
  const deductionHighlights = [
    {
      title: 'Standard Deductions',
      tag: '2024–2025',
      summary: 'Baseline deduction applied automatically if not itemizing on Schedule A:',
      items: [
        '$14,600 for Single & Married Filing Separately',
        '$29,200 for Married Couples Filing Jointly',
        '$21,900 for Head of Household filers',
      ],
    },
    {
      title: 'Family & Dependent Credits',
      tag: 'High Value',
      summary: 'Direct tax credits that dollar-for-dollar lower your tax balance:',
      items: [
        'Child Tax Credit: up to $2,000 per child ($1,700 refundable)',
        'Dependent Care Credit: up to $5,000 pre-tax savings',
        'Earned Income Tax Credit (EITC) for qualifying workers',
      ],
    },
    {
      title: 'Education & Retirement',
      tag: 'Above-the-Line',
      summary: 'Above-the-line deductions that lower your adjusted gross income:',
      items: [
        'Student Loan Interest: up to $2,500 deduction',
        'American Opportunity Credit: up to $2,500 per student',
        'Traditional IRA & 401(k) pre-tax retirement savings',
      ],
    },
  ];

  const title = "U.S. Tax Resources & Official Forms | IRS Tax Filer";
  const description = "Clean and verified U.S. tax resources: official IRS forms (1040, W-7, FBAR), 2025–2026 tax deadlines, and standard deduction guidelines.";
  const keywords = "IRS tax forms, Form 1040, Form W-7, FBAR 114, tax deadlines 2025 2026, standard deductions";
  const canonical = window.location.href;
  const image = { Logo };

  return (
    <>
      <SEO
        title={title}
        description={description}
        canonical={canonical}
        image={image}
        keywords={keywords}
      />

      <div className="min-h-screen bg-white font-sans text-gray-900">

        {/* ========================================================================= */}
        {/* 1. HERO SECTION (CLEAN, AIRY & MINIMAL)                                   */}
        {/* ========================================================================= */}
        <section className="relative pt-12 sm:pt-16 pb-12 sm:pb-16 bg-white border-b border-slate-100 text-center">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">

            {/* Eyebrow Pill */}
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.35 }}
              className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#F6F9EE] border border-[#749220]/30 shadow-2xs mb-4 text-xs font-medium text-[#749220] uppercase tracking-wider"
            >
              <SparklesIcon className="w-3.5 h-3.5 text-[#749220]" />
              <span>Tax Filing Knowledge Hub</span>
            </motion.div>

            {/* Headline */}
            <motion.h1
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: 0.08 }}
              className="text-3xl sm:text-4xl lg:text-[42px] font-normal text-gray-900 tracking-tight leading-[1.25] mb-3.5"
            >
              Essential Tax Resources &{' '}
              <span className="font-medium bg-gradient-to-r from-[#0A4973] via-[#165479] to-[#749220] bg-clip-text text-transparent">
                Official Forms
              </span>
            </motion.h1>

            {/* Concise Subtext */}
            <motion.p
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: 0.12 }}
              className="text-sm sm:text-base text-gray-600 font-normal leading-relaxed max-w-xl mx-auto mb-6"
            >
              Verified IRS downloads, critical 2025–2026 filing dates, and standard deduction guidelines for taxpayers, expats, and small businesses.
            </motion.p>

            {/* Subtle Trust Indicators */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.4, delay: 0.16 }}
              className="flex flex-wrap items-center justify-center gap-4 text-xs text-gray-500 font-normal"
            >
              <span className="inline-flex items-center gap-1.5">
                <CheckCircleIcon className="w-4 h-4 text-[#749220]" />
                Direct IRS.gov Links
              </span>
              <span className="text-gray-300">•</span>
              <span className="inline-flex items-center gap-1.5">
                <CheckCircleIcon className="w-4 h-4 text-[#749220]" />
                Updated for 2025
              </span>
              <span className="text-gray-300">•</span>
              <span className="inline-flex items-center gap-1.5">
                <CheckCircleIcon className="w-4 h-4 text-[#749220]" />
                CPA Reviewed
              </span>
            </motion.div>

          </div>
        </section>

        {/* ========================================================================= */}
        {/* 2. OFFICIAL IRS FORMS SECTION (SPLIT WITH 3D FORMS IMAGE)                 */}
        {/* ========================================================================= */}
        <section className="py-14 sm:py-18 bg-slate-50/60 border-b border-slate-100">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

            {/* Section Header */}
            <div className="text-left mb-8 sm:mb-10">
              <div className="inline-flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-[#749220] mb-1.5">
                <DocumentTextIcon className="w-4 h-4 text-[#749220]" />
                <span>Official Tax Forms</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-normal text-gray-900 tracking-tight">
                Commonly Used Forms & Instructions
              </h2>
              <p className="text-xs sm:text-sm text-gray-600 mt-1 max-w-2xl font-normal">
                Direct official PDF downloads hosted by the IRS and FinCEN repositories.
              </p>
            </div>

            {/* Split Composition: Left 3D Visual + Right 6 Clean Form Cards */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-center">

              {/* Left Column: 3D Forms Visual */}
              <div className="lg:col-span-5 flex justify-center">
                <motion.div
                  initial={{ opacity: 0, scale: 0.96 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4 }}
                  className="relative w-full max-w-[420px] rounded-2xl overflow-hidden border border-slate-200/90 shadow-[0_12px_36px_rgba(22,84,121,0.08)] bg-white group"
                >
                  <img
                    src={formsVisual}
                    alt="Official IRS Tax Forms 1040 and Verification Seal"
                    className="w-full h-auto max-h-[420px] object-cover transition-transform duration-500 group-hover:scale-[1.02]"
                    loading="lazy"
                  />

                  {/* Floating Glass Pill */}
                  <div className="absolute bottom-3.5 left-3.5 right-3.5 bg-white/95 backdrop-blur-md rounded-xl p-3 shadow-md border border-gray-200/80 flex items-center justify-between z-10 select-none">
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-[#749220] animate-pulse" />
                      <span className="text-xs font-semibold text-gray-900">
                        100% Official IRS PDFs
                      </span>
                    </div>
                    <span className="text-[10px] font-medium text-gray-500">
                      Form 1040, W-7 & FBAR
                    </span>
                  </div>
                </motion.div>
              </div>

              {/* Right Column: 6 Cards Grid (2 cols x 3 rows) */}
              <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-4">
                {essentialForms.map((item, idx) => (
                  <motion.div
                    key={item.code}
                    initial={{ opacity: 0, y: 12 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.3, delay: idx * 0.04 }}
                    className="bg-white rounded-xl p-4.5 border border-slate-200/80 shadow-2xs hover:shadow-[0_12px_28px_rgba(22,84,121,0.06)] hover:-translate-y-0.5 hover:border-[#165479]/30 transition-all duration-200 flex flex-col justify-between"
                  >
                    <div>
                      {/* Code & Tag */}
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-mono text-xs font-semibold text-[#165479] bg-sky-50 px-2 py-0.5 rounded border border-sky-100">
                          {item.code}
                        </span>
                        <span className="text-[10px] font-medium text-[#749220] bg-[#F6F9EE] px-2 py-0.5 rounded-full border border-[#749220]/20">
                          {item.tag}
                        </span>
                      </div>

                      <h3 className="text-sm font-semibold text-gray-900 mb-1 leading-snug">
                        {item.name}
                      </h3>

                      <p className="text-xs text-gray-600 font-normal leading-relaxed mb-3">
                        {item.summary}
                      </p>
                    </div>

                    {/* Links */}
                    <div className="pt-2.5 border-t border-slate-100 flex items-center justify-between text-xs">
                      <a
                        href={item.formUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 font-medium text-[#165479] hover:underline"
                      >
                        <span>Form PDF</span>
                        <ArrowTopRightOnSquareIcon className="w-3.5 h-3.5" />
                      </a>

                      <a
                        href={item.instructionsUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 font-medium text-gray-600 hover:text-gray-900 hover:underline"
                      >
                        <span>Instructions</span>
                        <ArrowTopRightOnSquareIcon className="w-3.5 h-3.5" />
                      </a>
                    </div>
                  </motion.div>
                ))}
              </div>

            </div>

          </div>
        </section>

        {/* ========================================================================= */}
        {/* 3. KEY TAX DEADLINES SECTION (BORDERLESS TIMELINE SCHEDULE)               */}
        {/* ========================================================================= */}
        <section className="py-14 sm:py-18 bg-white border-b border-slate-100">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

            {/* Section Header */}
            <div className="text-left mb-8 sm:mb-10">
              <div className="inline-flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-[#749220] mb-1.5">
                <CalendarDaysIcon className="w-4 h-4 text-[#749220]" />
                <span>2025–2026 Calendar</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-normal text-gray-900 tracking-tight">
                Important Filing Deadlines
              </h2>
              <p className="text-xs sm:text-sm text-gray-600 mt-1 max-w-2xl font-normal">
                Key federal dates to keep your filing on track and avoid IRS late penalties.
              </p>
            </div>

            {/* Split Composition: Left Borderless Timeline Schedule + Right 3D Calendar Visual */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">

              {/* Left Column: Borderless Timeline Schedule (Clean typography, no boxy card borders) */}
              <div className="lg:col-span-7 order-2 lg:order-1">
                <div className="divide-y divide-slate-100">
                  {keyDeadlines.map((item, idx) => (
                    <motion.div
                      key={idx}
                      initial={{ opacity: 0, x: -10 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.3, delay: idx * 0.06 }}
                      className={`flex items-start gap-3.5 sm:gap-4.5 py-3.5 sm:py-4 px-2.5 sm:px-3.5 rounded-xl transition-all ${item.highlight
                        ? 'bg-[#F6F9EE]/80'
                        : 'hover:bg-slate-50/80'
                        }`}
                    >
                      {/* Modern Clean Calendar Date Tile */}
                      <div
                        className={`w-14 h-14 sm:w-16 sm:h-16 rounded-2xl flex flex-col items-center justify-center shrink-0 border transition-all ${item.highlight
                          ? 'bg-[#165479] border-[#165479] text-white shadow-sm'
                          : 'bg-white border-slate-200/90 text-gray-900 shadow-2xs'
                          }`}
                      >
                        <span
                          className={`text-[10px] sm:text-[11px] font-bold uppercase tracking-wider leading-none ${item.highlight ? 'text-[#CBF056]' : 'text-[#749220]'
                            }`}
                        >
                          {item.month}
                        </span>
                        <span className="text-lg sm:text-xl font-bold leading-none tracking-tight mt-1">
                          {item.day}
                        </span>
                      </div>

                      {/* Content (Pure clean typography, no card frame) */}
                      <div className="flex-1 min-w-0 pt-0.5">
                        <div className="flex flex-wrap items-center gap-2 mb-1">
                          <h3 className="text-sm sm:text-base font-semibold text-gray-900 leading-snug">
                            {item.title}
                          </h3>
                          <span
                            className={`text-[10px] font-medium px-2 py-0.5 rounded-full ${item.highlight
                              ? 'bg-[#749220] text-white'
                              : 'bg-slate-200/80 text-gray-600'
                              }`}
                          >
                            {item.tag}
                          </span>
                        </div>

                        <p className="text-xs sm:text-[13px] text-gray-600 font-normal leading-relaxed">
                          {item.note}
                        </p>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>

              {/* Right Column: 3D Calendar Visual */}
              <div className="lg:col-span-5 flex justify-center order-1 lg:order-2">
                <motion.div
                  initial={{ opacity: 0, scale: 0.96 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4 }}
                  className="relative w-full max-w-[440px] rounded-2xl overflow-hidden border border-slate-200/90 shadow-[0_12px_36px_rgba(22,84,121,0.08)] bg-white group"
                >
                  <img
                    src={deadlinesVisual}
                    alt="2025–2026 U.S. Tax Filing Deadline Calendar with April 15 Highlighted"
                    className="w-full h-auto min-h-[380px] sm:min-h-[410px] lg:min-h-[440px] max-h-[470px] object-cover transition-transform duration-500 group-hover:scale-[1.02]"
                    loading="lazy"
                  />

                  {/* Floating Glass Pill */}
                  <div className="absolute bottom-3.5 left-3.5 right-3.5 bg-white/95 backdrop-blur-md rounded-xl p-3 shadow-md border border-gray-200/80 flex items-center justify-between z-10 select-none">
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                      <span className="text-xs font-semibold text-gray-900">
                        April 15 Primary Due Date
                      </span>
                    </div>
                    <span className="text-[10px] font-medium text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full">
                      On-Time Filing
                    </span>
                  </div>
                </motion.div>
              </div>

            </div>

          </div>
        </section>

        {/* ========================================================================= */}
        {/* 4. DEDUCTIONS & CREDITS SECTION (SPLIT WITH 3D DEDUCTIONS IMAGE)           */}
        {/* ========================================================================= */}
        <section className="py-14 sm:py-18 bg-slate-50/60 border-b border-slate-100">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

            {/* Section Header */}
            <div className="text-left mb-8 sm:mb-10">
              <div className="inline-flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-[#749220] mb-1.5">
                <BanknotesIcon className="w-4 h-4 text-[#749220]" />
                <span>Tax Savings & Credits</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-normal text-gray-900 tracking-tight">
                Standard Deductions & Key Credits
              </h2>
              <p className="text-xs sm:text-sm text-gray-600 mt-1 max-w-2xl font-normal">
                Check baseline deductions and high-value tax credits for the 2024–2025 tax year.
              </p>
            </div>

            {/* Split Composition: Left 3D Deductions Visual + Right 3 Deduction Columns */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-center">

              {/* Left Column: 3D Deductions Visual */}
              <div className="lg:col-span-5 flex justify-center">
                <motion.div
                  initial={{ opacity: 0, scale: 0.96 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4 }}
                  className="relative w-full max-w-[420px] rounded-2xl overflow-hidden border border-slate-200/90 shadow-[0_12px_36px_rgba(22,84,121,0.08)] bg-white group"
                >
                  <img
                    src={deductionsVisual}
                    alt="Standard Deductions and Tax Refund Savings Visualization"
                    className="w-full h-auto max-h-[420px] object-cover transition-transform duration-500 group-hover:scale-[1.02]"
                    loading="lazy"
                  />

                  {/* Floating Glass Pill */}
                  <div className="absolute bottom-3.5 left-3.5 right-3.5 bg-white/95 backdrop-blur-md rounded-xl p-3 shadow-md border border-gray-200/80 flex items-center justify-between z-10 select-none">
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-[#749220] animate-pulse" />
                      <span className="text-xs font-semibold text-gray-900">
                        Max Legal Deductions
                      </span>
                    </div>
                    <span className="text-[10px] font-medium text-[#749220] bg-[#F6F9EE] px-2 py-0.5 rounded-full border border-[#749220]/25">
                      CPA Optimized
                    </span>
                  </div>
                </motion.div>
              </div>

              {/* Right Column: 3 Deductions Cards */}
              <div className="lg:col-span-7 space-y-4">
                {deductionHighlights.map((col, idx) => (
                  <motion.div
                    key={idx}
                    initial={{ opacity: 0, y: 12 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.3, delay: idx * 0.05 }}
                    className="bg-white rounded-xl p-4.5 border border-slate-200/80 shadow-2xs hover:shadow-[0_12px_28px_rgba(22,84,121,0.06)] transition-all duration-200"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-sm sm:text-[15px] font-semibold text-gray-900">
                        {col.title}
                      </h3>
                      <span className="text-[10px] font-medium text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200/60">
                        {col.tag}
                      </span>
                    </div>

                    <p className="text-xs text-gray-500 font-normal mb-2.5 leading-relaxed">
                      {col.summary}
                    </p>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {col.items.map((point, pIdx) => (
                        <div key={pIdx} className="flex items-start gap-1.5 text-xs text-gray-700 font-normal">
                          <CheckCircleIcon className="w-3.5 h-3.5 text-[#749220] shrink-0 mt-0.5" />
                          <span className="leading-tight">{point}</span>
                        </div>
                      ))}
                    </div>
                  </motion.div>
                ))}
              </div>

            </div>

          </div>
        </section>

        {/* ========================================================================= */}
        {/* 5. CLEAN, MINIMAL CTA SECTION                                             */}
        {/* ========================================================================= */}
        <section className="py-14 sm:py-16 bg-white">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">

            <div className="rounded-2xl p-8 sm:p-10 bg-slate-50 border border-slate-200/90 shadow-2xs">

              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white border border-slate-200 text-xs font-medium text-gray-700 mb-3.5 shadow-2xs">
                <ShieldCheckIcon className="w-3.5 h-3.5 text-[#749220]" />
                <span>Certified CPA Support</span>
              </div>

              <h2 className="text-xl sm:text-2xl lg:text-3xl font-normal text-gray-900 tracking-tight mb-2.5">
                Need Help Selecting Forms or Maximizing Deductions?
              </h2>

              <p className="text-xs sm:text-sm text-gray-600 font-normal max-w-lg mx-auto mb-6 leading-relaxed">
                Our licensed CPAs review every return to ensure 100% IRS accuracy, audit protection, and your maximum legal refund.
              </p>

              <div className="flex flex-wrap items-center justify-center gap-3">
                <Link
                  to="/login"
                  className="inline-flex items-center justify-center gap-2 h-10 sm:h-11 px-5 rounded-xl bg-[#165479] hover:bg-[#0A4973] text-white font-medium text-xs sm:text-sm shadow-sm transition-all"
                >
                  <span>Start Filing Online</span>
                  <ArrowRightIcon className="w-3.5 h-3.5" />
                </Link>

                <Link
                  to="/contact"
                  className="inline-flex items-center justify-center gap-2 h-10 sm:h-11 px-5 rounded-xl bg-white hover:bg-slate-50 text-gray-800 font-medium text-xs sm:text-sm border border-slate-300 shadow-2xs transition-all"
                >
                  <span>Talk to a CPA</span>
                </Link>
              </div>

              <div className="mt-6 pt-5 border-t border-slate-200/60 flex flex-wrap items-center justify-center gap-x-5 gap-y-1.5 text-[11px] text-gray-500 font-normal">
                <span className="flex items-center gap-1">
                  <CheckBadgeIcon className="w-3.5 h-3.5 text-[#749220]" />
                  IRS Authorized e-File
                </span>
                <span>•</span>
                <span className="flex items-center gap-1">
                  <CheckCircleIcon className="w-3.5 h-3.5 text-[#749220]" />
                  All 50 States
                </span>
                <span>•</span>
                <span className="flex items-center gap-1">
                  <ShieldCheckIcon className="w-3.5 h-3.5 text-[#749220]" />
                  100% Accuracy Guarantee
                </span>
              </div>

            </div>

          </div>
        </section>

      </div>
    </>
  );
};

export default TaxResources;
