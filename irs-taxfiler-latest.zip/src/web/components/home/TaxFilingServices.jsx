import React, { useState } from "react";
import { Link } from "react-router-dom";
import { ArrowRightIcon } from "@heroicons/react/24/outline";

const TaxFilingServices = ({ onOpenModal }) => {
  const [selectedService, setSelectedService] = useState("us-individual");

  const serviceCategories = [
    {
      id: "us-individual",
      label: "US Individual Tax Services",
      countLabel: "6 Filing Services",
      icon: (
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
        </svg>
      ),
    },
    {
      id: "us-business",
      label: "US Business Tax Services",
      countLabel: "3 Corporate Services",
      icon: (
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
        </svg>
      ),
    },
    {
      id: "indian-tax",
      label: "Indian Tax Services",
      countLabel: "2 Compliance Services",
      icon: (
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      ),
    },
  ];

  const services = {
    "us-individual": {
      title: "US Individual Tax Services",
      subtitle: "Complete federal, state, and specialized compliance services for US individuals.",
      items: [
        {
          title: "Federal, State and Local Tax filing",
          description: "Complete federal, state, and local tax return preparation and filing services for US individuals.",
          tag: "Form 1040",
          route: "/services/us-individual/federal-state-local",
          icon: (
            <svg className="w-7 h-7" viewBox="0 0 20 20" fill="none">
              <rect x="3" y="2.5" width="14" height="15" rx="2.5" stroke="currentColor" strokeWidth="1.4" />
              <rect x="5.5" y="4.5" width="4.5" height="1.8" rx="0.5" fill="currentColor" />
              <line x1="5.5" y1="8.5" x2="14.5" y2="8.5" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" />
              <line x1="5.5" y1="11.5" x2="11.5" y2="11.5" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" />
              <circle cx="14" cy="14" r="3" fill="#10B981" />
              <path d="M12.8 14L13.6 14.8L15.2 13.2" stroke="white" strokeWidth="0.9" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          ),
        },
        {
          title: "FBAR & FATCA Services",
          description: "Foreign Bank Account Report (FBAR) and Foreign Account Tax Compliance Act (FATCA) filing assistance.",
          tag: "FBAR & FATCA",
          route: "/services/us-individual/fbar-fatca",
          icon: (
            <svg className="w-7 h-7" viewBox="0 0 20 20" fill="none">
              <circle cx="10" cy="10" r="7.5" stroke="currentColor" strokeWidth="1.4" />
              <ellipse cx="10" cy="10" rx="3.5" ry="7.5" stroke="currentColor" strokeWidth="1.1" strokeDasharray="1.5 1.5" />
              <line x1="2.5" y1="10" x2="17.5" y2="10" stroke="currentColor" strokeWidth="1.1" />
              <circle cx="14" cy="6" r="2.8" fill="#06B6D4" />
              <text x="14" y="8" fill="white" fontSize="4" fontWeight="bold" textAnchor="middle" fontFamily="sans-serif">$</text>
            </svg>
          ),
        },
        {
          title: "Representation Services",
          description: "Professional representation before the IRS for audits, appeals, and tax disputes.",
          tag: "IRS Audits",
          route: "/services/us-individual/representation",
          icon: (
            <svg className="w-7 h-7" viewBox="0 0 20 20" fill="none">
              <path d="M10 2L16.5 4.5V9.5C16.5 13.5 10 17.5 10 17.5C10 17.5 3.5 13.5 3.5 9.5V4.5L10 2Z" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round" />
              <circle cx="10" cy="9.5" r="3.2" fill="#F59E0B" />
              <path d="M8.5 9.5L9.5 10.5L11.8 8.2" stroke="white" strokeWidth="1" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          ),
        },
        {
          title: "ITIN Assistance",
          description: "Help with Individual Taxpayer Identification Number (ITIN) applications and renewals.",
          tag: "Form W-7",
          route: "/services/us-individual/itin",
          icon: (
            <svg className="w-7 h-7" viewBox="0 0 20 20" fill="none">
              <rect x="2.5" y="4" width="15" height="12" rx="2.5" stroke="currentColor" strokeWidth="1.4" />
              <circle cx="7" cy="9" r="2" stroke="currentColor" strokeWidth="1.2" />
              <path d="M4.5 13.5C4.5 12 5.5 11.5 7 11.5C8.5 11.5 9.5 12 9.5 13.5" stroke="currentColor" strokeWidth="1.2" />
              <line x1="11.5" y1="8" x2="15.5" y2="8" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" />
              <line x1="11.5" y1="11" x2="14" y2="11" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" />
            </svg>
          ),
        },
        {
          title: "Extension Filing",
          description: "File tax extensions to get additional time to prepare and submit your tax returns.",
          tag: "Form 4868",
          route: "/services/us-individual/extension",
          icon: (
            <svg className="w-7 h-7" viewBox="0 0 20 20" fill="none">
              <circle cx="10" cy="10.5" r="7" stroke="currentColor" strokeWidth="1.4" />
              <path d="M10 6.5V10.5L12.5 12" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" />
              <path d="M7 2.5H13" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" />
            </svg>
          ),
        },
        {
          title: "Amendment Filing",
          description: "Amend previously filed federal and state returns to correct errors or claim missed refunds.",
          tag: "Form 1040-X",
          route: "/services/us-individual/extension",
          icon: (
            <svg className="w-7 h-7" viewBox="0 0 20 20" fill="none">
              <path d="M4 3.5C4 2.67 4.67 2 5.5 2H12L16 6V16.5C16 17.33 15.33 18 14.5 18H5.5C4.67 18 4 17.33 4 16.5V3.5Z" stroke="currentColor" strokeWidth="1.4" />
              <path d="M11.5 2V6.5H16" stroke="currentColor" strokeWidth="1.2" />
              <path d="M7.5 14L13 8.5M13 8.5L11 6.5M13 8.5L14.5 10" stroke="#F43F5E" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          ),
        },
      ],
    },
    "us-business": {
      title: "US Business Tax Services",
      subtitle: "Comprehensive business incorporations and tax filing solutions for companies.",
      items: [
        {
          title: "US Incorporations",
          description: "Assistance with business incorporation, entity selection, and tax structure setup.",
          tag: "Entity Setup",
          route: "/services/us-business/incorporations",
          icon: (
            <svg className="w-7 h-7" viewBox="0 0 20 20" fill="none">
              <path d="M3 17.5H17M4.5 17.5V6.5L10 3L15.5 6.5V17.5" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round" />
              <rect x="7.5" y="9" width="2" height="2.5" stroke="currentColor" strokeWidth="1.1" />
              <rect x="10.5" y="9" width="2" height="2.5" stroke="currentColor" strokeWidth="1.1" />
              <rect x="9" y="13.5" width="2" height="4" stroke="currentColor" strokeWidth="1.1" />
            </svg>
          ),
        },
        {
          title: "Small & Medium Business Tax filing",
          description: "Comprehensive tax preparation and filing services for small and medium-sized businesses.",
          tag: "Form 1120 / 1065",
          route: "/services/us-business/smb-tax-filing",
          icon: (
            <svg className="w-7 h-7" viewBox="0 0 20 20" fill="none">
              <rect x="3" y="3.5" width="14" height="13.5" rx="2" stroke="currentColor" strokeWidth="1.4" />
              <line x1="6" y1="13.5" x2="6" y2="10" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
              <line x1="10" y1="13.5" x2="10" y2="7.5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
              <line x1="14" y1="13.5" x2="14" y2="11.5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
              <path d="M5.5 8L9.5 5.5L14.5 9" stroke="#10B981" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          ),
        },
        {
          title: "Consulting with Tax Expert (CPA)",
          description: "Personalized corporate tax advisory and planning sessions with licensed US CPAs.",
          tag: "Advisory Call",
          route: "/services/us-business/smb-tax-filing",
          icon: (
            <svg className="w-7 h-7" viewBox="0 0 20 20" fill="none">
              <circle cx="10" cy="7" r="3.5" stroke="currentColor" strokeWidth="1.4" />
              <path d="M4 17C4 13.7 6.7 11 10 11C13.3 11 16 13.7 16 17" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" />
              <circle cx="15" cy="5" r="2.2" fill="#0D9488" />
              <path d="M14.2 5L14.8 5.6L16 4.4" stroke="white" strokeWidth="0.8" strokeLinecap="round" />
            </svg>
          ),
        },
      ],
    },
    "indian-tax": {
      title: "Indian Tax Services",
      subtitle: "Income tax return filing and professional representation before Indian tax authorities.",
      items: [
        {
          title: "Indian tax Filing",
          description: "Income Tax Return (ITR) filing services for individuals, businesses, and other entities in India.",
          tag: "ITR Filing",
          route: "/services/indian/tax-filing",
          icon: (
            <svg className="w-7 h-7" viewBox="0 0 20 20" fill="none">
              <rect x="3" y="2.5" width="14" height="15" rx="2.5" stroke="currentColor" strokeWidth="1.4" />
              <line x1="6" y1="6" x2="14" y2="6" stroke="#F97316" strokeWidth="1.5" strokeLinecap="round" />
              <line x1="6" y1="9.5" x2="14" y2="9.5" stroke="#64748B" strokeWidth="1.2" strokeLinecap="round" />
              <line x1="6" y1="13" x2="14" y2="13" stroke="#16A34A" strokeWidth="1.5" strokeLinecap="round" />
              <circle cx="10" cy="9.5" r="1.3" stroke="#0A4973" strokeWidth="0.8" />
            </svg>
          ),
        },
        {
          title: "Representation Services",
          description: "Professional representation before Indian tax authorities for assessments, appeals, and disputes",
          tag: "IT Authorities",
          route: "/services/indian/representation",
          icon: (
            <svg className="w-7 h-7" viewBox="0 0 20 20" fill="none">
              <path d="M10 2L16.5 4.5V9.5C16.5 13.5 10 17.5 10 17.5C10 17.5 3.5 13.5 3.5 9.5V4.5L10 2Z" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round" />
              <circle cx="10" cy="9.5" r="3" stroke="#DC2626" strokeWidth="1.2" />
              <line x1="10" y1="7.5" x2="10" y2="11.5" stroke="#DC2626" strokeWidth="1.2" strokeLinecap="round" />
              <line x1="8" y1="9.5" x2="12" y2="9.5" stroke="#DC2626" strokeWidth="1.2" strokeLinecap="round" />
            </svg>
          ),
        },
      ],
    },
  };

  const consultationCards = {
    "us-individual": {
      tag: "Free 15-Min Call",
      title: "CPA 1-on-1 Advisory Session",
      action: "Book free call",
      note: "No obligation",
      icon: (
        <svg className="w-7 h-7" viewBox="0 0 20 20" fill="none">
          <circle cx="10" cy="7" r="3.5" stroke="currentColor" strokeWidth="1.4" />
          <path d="M4 17C4 13.7 6.7 11 10 11C13.3 11 16 13.7 16 17" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" />
          <circle cx="15" cy="5" r="2.2" fill="#749220" />
          <path d="M14.2 5L14.8 5.6L16 4.4" stroke="white" strokeWidth="0.8" strokeLinecap="round" />
        </svg>
      ),
    },
    "us-business": {
      tag: "Free 15-Min Call",
      title: "Corporate CPA Advisory",
      action: "Book business call",
      note: "No obligation",
      icon: (
        <svg className="w-7 h-7" viewBox="0 0 20 20" fill="none">
          <circle cx="10" cy="7" r="3.5" stroke="currentColor" strokeWidth="1.4" />
          <path d="M4 17C4 13.7 6.7 11 10 11C13.3 11 16 13.7 16 17" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" />
          <circle cx="15" cy="5" r="2.2" fill="#749220" />
          <path d="M14.2 5L14.8 5.6L16 4.4" stroke="white" strokeWidth="0.8" strokeLinecap="round" />
        </svg>
      ),
    },
    "indian-tax": {
      tag: "Free 15-Min Call",
      title: "NRI & India Tax Advisory",
      action: "Book NRI consultation",
      note: "No obligation",
      icon: (
        <svg className="w-7 h-7" viewBox="0 0 20 20" fill="none">
          <circle cx="10" cy="7" r="3.5" stroke="currentColor" strokeWidth="1.4" />
          <path d="M4 17C4 13.7 6.7 11 10 11C13.3 11 16 13.7 16 17" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" />
          <circle cx="15" cy="5" r="2.2" fill="#749220" />
          <path d="M14.2 5L14.8 5.6L16 4.4" stroke="white" strokeWidth="0.8" strokeLinecap="round" />
        </svg>
      ),
    },
  };

  return (
    <section className="relative py-12 sm:py-16 lg:py-20 bg-white border-y border-gray-100 font-sans">
      <div className="relative max-w-7xl xl:max-w-[1420px] mx-auto px-4 sm:px-6 lg:px-8">

        {/* 2-Column Split Layout: Sticky Left Tabs Navigation + Right Cards Grid */}
        <div className="flex flex-col lg:flex-row items-start gap-8 lg:gap-8 xl:gap-10">

          {/* Left Column: Heading + Sticky Vertical Category Tabs */}
          <div className="w-full lg:w-[280px] xl:w-[310px] shrink-0 lg:sticky lg:top-28 text-left">
            {/* Eyebrow Pill */}
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#F6F9EE] border border-[#749220]/25 text-xs font-normal text-[#749220] uppercase tracking-wider mb-3.5">
              <span className="w-1.5 h-1.5 rounded-full bg-[#749220]" />
              <span>Full-Service Tax Preparation</span>
            </div>

            {/* Section Headline */}
            <h2 className="text-2xl sm:text-3xl lg:text-[34px] font-normal text-gray-900 tracking-tight leading-[1.25]">
              Explore Our{" "}
              <span className="font-medium bg-gradient-to-r from-[#0A4973] via-[#165479] to-[#749220] bg-clip-text text-transparent">
                Filing Services
              </span>
            </h2>

            <p className="text-sm text-gray-500 mt-3 font-normal leading-relaxed">
              Certified CPA preparation, dual-status compliance, and maximum refunds tailored for US and Indian taxpayers.
            </p>

            {/* Vertical Category Switcher Stack */}
            <div className="mt-8 flex flex-col gap-2.5 sm:gap-3 w-full">
              {serviceCategories.map((cat) => {
                const isActive = selectedService === cat.id;
                const count = services[cat.id]?.items.length || 0;
                return (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => setSelectedService(cat.id)}
                    className={`group w-full text-left p-3.5 sm:p-4 rounded-2xl transition-all duration-200 cursor-pointer flex items-center justify-between border ${isActive
                      ? "bg-gradient-to-r from-[#0A4973] via-[#165479] to-[#0D3B5C] text-white shadow-[0_8px_24px_rgba(22,84,121,0.22)] border-[#165479]"
                      : "bg-slate-50/80 hover:bg-white text-slate-700 border-slate-200/80 hover:border-slate-300 hover:shadow-xs"
                      }`}
                  >
                    <div className="flex items-center gap-3.5">
                      <div
                        className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 transition-colors ${isActive
                          ? "bg-white/10 backdrop-blur-sm text-[#CBF056] border border-white/20"
                          : "bg-white text-slate-500 border border-slate-200/80 group-hover:text-[#165479] group-hover:border-[#165479]/40"
                          }`}
                      >
                        {cat.icon}
                      </div>
                      <div>
                        <div className={`text-[14px] sm:text-[15px] font-medium leading-snug ${isActive ? "text-white" : "text-slate-800 group-hover:text-[#165479]"}`}>
                          {cat.label}
                        </div>
                        <div className={`text-xs mt-0.5 ${isActive ? "text-white/70" : "text-slate-500"}`}>
                          {count} {count === 1 ? "Service" : "Services"}
                        </div>
                      </div>
                    </div>
                    <ArrowRightIcon
                      className={`w-4 h-4 shrink-0 transition-transform ${isActive
                        ? "text-[#CBF056] translate-x-1"
                        : "text-slate-400 group-hover:text-slate-600 group-hover:translate-x-1"
                        }`}
                    />
                  </button>
                );
              })}
            </div>
          </div>

          {/* Right Column: Service Cards Grid (3 Cards per row on Desktop) */}
          <div className="flex-1 w-full">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5 sm:gap-4">
              {services[selectedService]?.items.map((item, idx) => (
                <Link
                  key={`${selectedService}-${idx}`}
                  to={item.route || "/login"}
                  className="group relative bg-white hover:bg-[#FAFCFE] rounded-2xl border border-slate-200/90 hover:border-[#165479]/50 shadow-[0_2px_12px_rgba(22,84,121,0.04)] hover:shadow-[0_16px_36px_rgba(22,84,121,0.1)] hover:-translate-y-1 transition-all duration-300 p-4 sm:p-5 flex flex-col justify-between text-left overflow-hidden min-h-[170px]"
                >
                  <div>
                    {/* Top Row: Direct Icon + Tag Pill */}
                    <div className="flex items-center justify-between mb-4">
                      <div className="w-9 h-9 flex items-center justify-center shrink-0 text-[#165479] group-hover:text-[#749220] group-hover:scale-110 transition-all duration-200">
                        {item.icon}
                      </div>
                      {item.tag && (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-slate-50 border border-slate-200/80 text-[11px] font-medium text-slate-600 shadow-2xs">
                          <span className="w-1.5 h-1.5 rounded-full bg-[#749220]" />
                          <span>{item.tag}</span>
                        </span>
                      )}
                    </div>

                    {/* Clean Title Only */}
                    <h3 className="text-[14.5px] sm:text-[15px] font-medium text-gray-900 group-hover:text-[#165479] transition-colors leading-snug">
                      {item.title}
                    </h3>
                  </div>

                  {/* Footer Action Link */}
                  <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                    <span className="text-xs font-semibold text-[#165479] group-hover:text-[#749220] transition-colors flex items-center gap-1.5">
                      <span>Start filing</span>
                      <ArrowRightIcon className="w-3.5 h-3.5 stroke-[2.2] group-hover:translate-x-1 transition-transform" />
                    </span>
                    <span className="text-[11px] font-medium text-slate-400">
                      {selectedService === "indian-tax" ? "ITD e-filing" : "IRS e-file"}
                    </span>
                  </div>
                </Link>
              ))}

              {/* Consultation Card - Seamlessly completes the 3-column row */}
              {consultationCards[selectedService] && (
                <div
                  onClick={onOpenModal}
                  className="group relative bg-white hover:bg-[#FAFCFE] rounded-2xl border border-slate-200/90 hover:border-[#749220]/50 shadow-[0_2px_12px_rgba(22,84,121,0.04)] hover:shadow-[0_16px_36px_rgba(116,146,32,0.12)] hover:-translate-y-1 transition-all duration-300 p-4 sm:p-5 flex flex-col justify-between text-left cursor-pointer overflow-hidden min-h-[170px]"
                >
                  <div>
                    {/* Top Row: Direct Icon + Tag Pill */}
                    <div className="flex items-center justify-between mb-4">
                      <div className="w-9 h-9 flex items-center justify-center shrink-0 text-[#749220] group-hover:text-[#165479] group-hover:scale-110 transition-all duration-200">
                        {consultationCards[selectedService].icon}
                      </div>
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-[#F6F9EE] border border-[#749220]/30 text-[11px] font-medium text-[#749220] shadow-2xs">
                        <span className="w-1.5 h-1.5 rounded-full bg-[#749220] animate-pulse" />
                        <span>{consultationCards[selectedService].tag}</span>
                      </span>
                    </div>

                    {/* Title Only */}
                    <h3 className="text-[14.5px] sm:text-[15px] font-medium text-gray-900 group-hover:text-[#749220] transition-colors leading-snug">
                      {consultationCards[selectedService].title}
                    </h3>
                  </div>

                  {/* Footer Action Link */}
                  <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                    <span className="text-xs font-semibold text-[#749220] group-hover:text-[#165479] transition-colors flex items-center gap-1.5">
                      <span>{consultationCards[selectedService].action}</span>
                      <ArrowRightIcon className="w-3.5 h-3.5 stroke-[2.2] group-hover:translate-x-1 transition-transform" />
                    </span>
                    <span className="text-[11px] font-medium text-slate-400">
                      {consultationCards[selectedService].note}
                    </span>
                  </div>
                </div>
              )}
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};

export default TaxFilingServices;

