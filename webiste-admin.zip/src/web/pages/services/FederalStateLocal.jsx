﻿import React, { useState } from "react";
import { Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import {
  DocumentTextIcon,
  BuildingOffice2Icon,
  MapPinIcon,
  CheckCircleIcon,
  ArrowRightIcon,
  ShieldCheckIcon,
  ChevronDownIcon,
  CalendarDaysIcon,
  CheckBadgeIcon,
} from "@heroicons/react/24/outline";

import SEO from "../../components/seo/SEO";
import LeadModal from "../../components/popup";
import Logo from "../../assets/irsLogo.png";
import individualPhoto from "../../assets/services/individual-1040.jpg";
import multiStatePhoto from "../../assets/services/multi-state.jpg";
import { serviceCardThemes, serviceStepThemes } from "../../constants/serviceThemes";

const FederalStateLocal = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleOpenModal = () => setIsModalOpen(true);
  const handleCloseModal = () => setIsModalOpen(false);

  const title = "U.S. Federal, State & Local Tax Filing | CPA-Reviewed | IRS Tax Filer";
  const description =
    "File your U.S. federal Form 1040, multi-state SALT returns, and municipal local taxes online with certified CPA guidance. Guaranteed maximum refund and 100% IRS accuracy.";
  const keywords =
    "federal tax filing, state tax return, local municipal tax, Form 1040, multi-state tax filing, SALT deductions, CPA tax review, IRS Tax Filer";
  const canonical = window.location.href;
  const image = Logo;

  const filingJurisdictions = [
    {
      title: "Federal Tax Filing",
      tag: "Form 1040",
      icon: <DocumentTextIcon className="w-5 h-5 text-teal" />,
      description: "Full federal income tax preparation with deduction audits for individuals, families, and freelancers.",
      points: [
        "Form 1040, W-2 & 1099 e-file",
        "Itemized vs. standard deduction audit",
        "Child, EV, EITC & education credits",
      ],
      compliance: "IRS Authorized Direct e-File",
    },
    {
      title: "State Tax Filing",
      tag: "All 50 States",
      icon: <BuildingOffice2Icon className="w-5 h-5 text-primary" />,
      description: "Multi-state returns ensuring full credit offsets and zero double-taxation across state lines.",
      points: [
        "Resident, part-year & non-resident returns",
        "Out-of-state tax credit reconciliation",
        "Remote worker & commuter compliance",
      ],
      compliance: "50-State SALT e-File",
    },
    {
      title: "City & Local Taxes",
      tag: "Municipal",
      icon: <MapPinIcon className="w-5 h-5 text-teal" />,
      description: "Specialized compliance for cities, counties, and school districts with local tax requirements.",
      points: [
        "NYC, Philadelphia, Ohio RITA & MI cities",
        "Local earned income tax (EIT) filings",
        "Municipal withholding reconciliation",
      ],
      compliance: "Municipal Tax Compliant",
    },
  ];

  const processSteps = [
    {
      step: "01",
      title: "Upload Documents",
      description: "Upload your W-2s, 1099s, and deduction receipts to your encrypted portal.",
    },
    {
      step: "02",
      title: "CPA Prepares Return",
      description: "A licensed CPA reviews eligible write-offs and drafts your complete return.",
    },
    {
      step: "03",
      title: "Review & Sign",
      description: "Check your line-by-line refund calculation and approve before submission.",
    },
    {
      step: "04",
      title: "Direct IRS e-File",
      description: "Direct electronic filing with real-time tracking until your refund arrives.",
    },
  ];


  return (
    <div className="bg-white text-primary font-sans antialiased">
      <SEO
        title={title}
        description={description}
        canonical={canonical}
        image={image}
        keywords={keywords}
      />

      {/* 1. HERO SECTION: EXACT MATCH TYPOGRAPHY + REAL IMAGE (NO BREADCRUMBS) */}
      <section className="relative overflow-hidden pt-8 sm:pt-10 lg:pt-12 pb-8 sm:pb-10 bg-white">
        <div className="absolute top-1/4 right-10 w-[500px] h-[500px] bg-gradient-to-bl from-[#1F4264]/[0.05] via-[#127EAB]/[0.04] to-transparent rounded-full blur-3xl pointer-events-none" />

        <div className="relative max-w-7xl 2xl:max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-center">
            {/* Left Content Column */}
            <div className="lg:col-span-7 xl:col-span-7 text-left font-sans">
              {/* Main Headline - Matches Home Hero Typography exactly */}
              <motion.h1
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.1 }}
                style={{ lineHeight: 1.18 }}
                className="text-3xl sm:text-4xl md:text-5xl lg:text-[44px] xl:text-[48px] 2xl:text-[52px] font-normal text-primary tracking-tight mb-4 sm:mb-5"
              >
                Federal, State & Local <br className="hidden sm:inline" />
                <span className="font-medium text-teal">Tax Filing,</span> <span className="font-medium text-coral">Simplified.</span>
              </motion.h1>

              {/* Subheading - Matches Home Hero Typography exactly */}
              <motion.p
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.15 }}
                className="text-sm sm:text-base lg:text-[17px] text-slateText font-medium leading-[30px] sm:leading-[32px] lg:leading-[34px] mb-6 max-w-2xl"
              >
                Complete CPA preparation for your Form 1040, multi-state allocations, and city taxes with guaranteed maximum refunds and 100% IRS accuracy.
              </motion.p>

              {/* Action Buttons */}
              <motion.div
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="flex flex-wrap sm:flex-nowrap items-center gap-3 mb-6"
              >
                <Link
                  to="/login"
                  className="relative inline-flex items-center justify-center gap-2.5 h-11 sm:h-12 px-6 rounded-xl bg-primary hover:bg-primary-dark text-white font-semibold text-sm sm:text-[15px] shadow-sm hover:shadow-md transition-all duration-200 group overflow-hidden shrink-0"
                >
                  <span>Start Filing</span>
                  <ArrowRightIcon className="w-4 h-4 stroke-[2.2] group-hover:translate-x-1 transition-transform" />
                </Link>

                <button
                  type="button"
                  onClick={handleOpenModal}
                  className="relative inline-flex items-center justify-center gap-2.5 h-11 sm:h-12 px-6 rounded-xl bg-white hover:bg-background-blue text-teal hover:text-teal border border-border hover:border-teal font-semibold text-sm sm:text-[15px] shadow-sm hover:shadow-md hover:-translate-y-0.5 active:translate-y-0 transition-all duration-200 group cursor-pointer shrink-0"
                >
                  <CalendarDaysIcon className="w-4 h-4 text-teal group-hover:scale-110 transition-transform stroke-[2.2]" />
                  <span>Talk to CPA</span>
                </button>
              </motion.div>

              {/* Service Guarantees */}
              <div className="pt-4 border-t border-slate-100 flex items-center gap-2 text-xs text-slateText">
                <ShieldCheckIcon className="w-4 h-4 text-teal" />
                <span className="font-medium text-primary">Licensed CPAs & Enrolled Agents</span>
                <span className="text-border">•</span>
                <span>Direct Electronic Filing to IRS & State Agencies</span>
              </div>
            </div>

            {/* Right Column: Clean Showcase with Real Image */}
            <div className="lg:col-span-5 xl:col-span-5 relative flex justify-center lg:justify-end">
              <div className="relative w-full max-w-[460px]">
                {/* Main Image Card */}
                <div className="relative rounded-2xl overflow-hidden border border-slate-200/90 shadow-[0_16px_40px_rgba(22,84,121,0.08)] bg-white group">
                  {/* Subtle Header Bar */}
                  <div className="px-4 py-2.5 bg-slate-50/90 border-b border-slate-100 flex items-center justify-between text-xs">
                    <span className="font-semibold text-primary flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-[#127EAB]" />
                      Form 1040 Multi-Jurisdiction Filing
                    </span>
                  </div>

                  {/* Image */}
                  <img
                    src={individualPhoto}
                    alt="U.S. Federal, State and Local Tax Preparation"
                    className="w-full h-[280px] sm:h-[320px] object-cover transition-transform duration-500 group-hover:scale-[1.01]"
                    loading="eager"
                  />

                  {/* Clean Bottom Caption Strip */}
                  <div className="px-4 py-3 bg-white border-t border-slate-100 flex items-center justify-between text-xs text-slateText">
                    <span className="flex items-center gap-1.5">
                      <CheckBadgeIcon className="w-4 h-4 text-primary" />
                      <span>Dual CPA Line-by-Line Review</span>
                    </span>
                    <span className="font-semibold text-teal">
                      100% IRS Accuracy
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. JURISDICTION FILING TIERS WITH SECONDARY IMAGE */}
      <section className="py-8 sm:py-10 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-xl mx-auto mb-10 sm:mb-12">
            <h2 className="text-2xl sm:text-3xl font-normal text-primary tracking-tight leading-tight">
              Complete Coverage for{" "}
              <span className="font-medium text-teal">
                Every Level
              </span>
            </h2>
            <p className="text-sm sm:text-base text-slateText font-medium leading-relaxed mt-2.5">
              From federal Form 1040 to multi-state SALT allocations and city taxes.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
            {/* Secondary Image: Multi-State SALT Visual */}
            <div className="lg:col-span-4 rounded-2xl overflow-hidden border border-slate-200/90 shadow-2xs relative group min-h-[260px] flex flex-col justify-end">
              <img
                src={multiStatePhoto}
                alt="Multi-State Tax Allocation and SALT Credit Filings"
                className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-[1.02]"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent pointer-events-none" />
              <div className="relative z-10 p-5 text-left text-white">
                <h3 className="text-base font-semibold text-white leading-snug">
                  Multi-State & Remote Worker Tax Returns
                </h3>
                <p className="text-xs text-white/80 font-medium mt-1 leading-relaxed">
                  We calculate out-of-state credits so you never get double-taxed.
                </p>
              </div>
            </div>

            {/* 3 Jurisdiction Cards */}
            <div className="lg:col-span-8 grid grid-cols-1 md:grid-cols-3 gap-4">
              {filingJurisdictions.map((tier, idx) => {
                const theme = serviceCardThemes[idx % serviceCardThemes.length];
                const cardNum = String(idx + 1).padStart(2, "0");

                return (
                  <div
                    key={idx}
                    className={`group relative overflow-hidden ${theme.cardBg} rounded-2xl p-5 border ${theme.cardBorder} shadow-2xs ${theme.shadowHover} hover:-translate-y-0.5 transition-all duration-300 flex flex-col justify-between text-left`}
                  >
                    {/* Top Accent Strip */}
                    <div className={`absolute top-0 inset-x-0 h-0.5 bg-gradient-to-r from-transparent ${theme.topLine} to-transparent transition-all duration-300`} />

                    {/* Watermark Number */}
                    <span
                      aria-hidden="true"
                      className={`absolute -bottom-2 -right-1 text-6xl font-semibold font-mono tracking-tighter ${theme.watermark} select-none pointer-events-none transition-transform duration-300 group-hover:scale-110`}
                    >
                      {cardNum}
                    </span>

                    <div className="relative z-10">
                      <div className="flex items-center justify-between gap-2 mb-3.5">
                        <div className={`w-10 h-10 rounded-xl border ${theme.iconBox} flex items-center justify-center shrink-0 shadow-2xs group-hover:scale-105 transition-transform`}>
                          {React.cloneElement(tier.icon, { className: "w-5 h-5" })}
                        </div>
                        <span className={`text-[10.5px] font-semibold px-2.5 py-0.5 rounded-full border ${theme.badge}`}>
                          {tier.tag}
                        </span>
                      </div>

                      <h3 className={`text-base font-semibold ${theme.titleColor} leading-snug`}>
                        {tier.title}
                      </h3>

                      <p className="text-xs sm:text-[13px] text-slateText font-[500] leading-relaxed mt-1.5 mb-3.5">
                        {tier.description}
                      </p>

                      <ul className="space-y-2.5 pt-3 border-t border-slate-200/60">
                        {tier.points.map((pt, pIdx) => (
                          <li key={pIdx} className="flex items-start gap-2 text-xs sm:text-[13px] text-primary font-medium leading-snug">
                            <CheckCircleIcon className={`w-4 h-4 ${theme.checkColor} stroke-[2.2] shrink-0 mt-0.5`} />
                            <span>{pt}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* 3. SIMPLE 4-STEP WORKFLOW */}
      <section className="py-8 sm:py-10 bg-slate-50/60">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-xl mx-auto mb-10">
            <h2 className="text-2xl sm:text-3xl font-normal text-primary tracking-tight leading-tight">
              How It{" "}
              <span className="font-medium text-teal">
                Works
              </span>
            </h2>
            <p className="text-sm sm:text-base text-slateText font-[500] leading-relaxed mt-2.5">
              4 simple steps to your complete CPA-prepared tax return.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5">
            {processSteps.map((step, sIdx) => {
              const stepTheme = serviceStepThemes[sIdx % serviceStepThemes.length];

              return (
                <div
                  key={sIdx}
                  className={`group relative overflow-hidden ${stepTheme.cardBg} rounded-2xl p-5 border ${stepTheme.cardBorder} shadow-2xs hover:shadow-sm hover:-translate-y-0.5 transition-all duration-200 text-left`}
                >
                  {/* Top Accent Line */}
                  <div className={`absolute top-0 inset-x-0 h-0.5 bg-gradient-to-r from-transparent ${stepTheme.topLine} to-transparent transition-all duration-300`} />

                  {/* Watermark Step Number */}
                  <span
                    aria-hidden="true"
                    className={`absolute -bottom-2 -right-1 text-6xl font-semibold font-mono tracking-tighter ${stepTheme.watermark} select-none pointer-events-none transition-transform duration-300 group-hover:scale-105`}
                  >
                    {step.step}
                  </span>

                  <div className="relative z-10">
                    <div className={`inline-flex items-center justify-center px-2.5 h-8 rounded-lg font-semibold text-xs mb-3.5 font-mono border shadow-2xs ${stepTheme.badge}`}>
                      STEP {step.step}
                    </div>
                    <h3 className={`text-base font-semibold ${stepTheme.titleColor} leading-snug`}>
                      {step.title}
                    </h3>
                    <p className="text-xs sm:text-[13px] text-slateText font-[500] mt-1.5 leading-relaxed">
                      {step.description}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>


      {/* 5. CLEAN BOTTOM CTA BANNER */}
      <section className="py-8 sm:py-10 bg-white font-sans">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="relative overflow-hidden rounded-3xl py-10 sm:py-12 px-6 sm:px-12 bg-gradient-to-r from-[#0D6388] via-[#127EAB] to-[#168BB8] text-white shadow-xl text-center">
            {/* Subtle Ambient Glows */}
            <div className="absolute -top-24 -left-16 w-72 h-72 bg-white/10 rounded-full blur-3xl pointer-events-none" />
            <div className="absolute -bottom-24 -right-16 w-72 h-72 bg-[#1F4264]/25 rounded-full blur-3xl pointer-events-none" />

            <div className="max-w-3xl mx-auto relative z-10">
              <h2 className="text-2xl sm:text-3xl font-semibold tracking-tight text-white mb-2.5">
                Ready to file your Federal{" "}
                <span className="text-[#EE6450]">& State taxes?</span>
              </h2>
              <p className="text-xs sm:text-sm text-sky-50/90 max-w-xl mx-auto mb-7 font-medium leading-relaxed">
                Certified CPA preparation with guaranteed maximum refunds and 100% IRS accuracy.
              </p>

              <div className="flex flex-wrap items-center justify-center gap-3.5">
                <Link
                  to="/login"
                  className="inline-flex items-center justify-center gap-2 h-11 px-6 rounded-xl bg-white hover:bg-[#EFF9FB] text-primary font-semibold text-xs sm:text-sm transition-all duration-200 shadow-md hover:shadow-lg group"
                >
                  <span>Start Filing</span>
                  <ArrowRightIcon className="w-4 h-4 text-teal group-hover:translate-x-1 transition-transform" />
                </Link>
                <button
                  type="button"
                  onClick={handleOpenModal}
                  className="inline-flex items-center justify-center gap-2 h-11 px-5 rounded-xl bg-white/15 hover:bg-white/25 text-white font-semibold text-xs sm:text-sm border border-white/30 backdrop-blur-xs transition-all duration-200 cursor-pointer group"
                >
                  <CalendarDaysIcon className="w-4 h-4 text-white/90 stroke-[2] group-hover:scale-110 transition-transform" />
                  <span>Talk to CPA</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Lead Generation Modal */}
      <LeadModal open={isModalOpen} onClose={handleCloseModal} />
    </div>
  );
};

export default FederalStateLocal;
